'use client';

import React, { FC, useState } from 'react';
import MyDropzone from '@/components/dropzone';
import BooksPage from './table';

const DropzonesWithTable: FC = () => {
  const [tableData, setTableData] = useState<Record<string, string | number>[]>([]);
  const [show, setShow] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  // Fields your Flask API expects
  const apiFields = [
    "title",
    "authors",
    "publication_date",
    "ratings_count",
    "num_pages",
    "text_reviews_count",
    "language_code",
    "publisher",
  ];

  const handleFileDrop = async (rows: Record<string, string>[]) => {
    setLoading(true);
    const enrichedData: Record<string, string | number>[] = [];

    for (const row of rows) {
      try {
        // Build payload ONLY with API-supported fields
        const payload: any = {};
        apiFields.forEach((field) => {
          if (row[field] !== undefined && row[field] !== null) {
            if (["ratings_count", "num_pages", "text_reviews_count"].includes(field)) {
              payload[field] = Number(row[field]) || 0;
            } else {
              payload[field] = row[field];
            }
          } else {
            // Fill defaults if missing
            payload[field] = ["ratings_count", "num_pages", "text_reviews_count"].includes(field)
              ? 0
              : "";
          }
        });

        // Call Flask API
        const response = await fetch("https://api-ml-project.onrender.com/predict", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const result = await response.json();

        if (response.ok) {
          enrichedData.push({
            ...row, // keep ALL original columns (isbn, isbn13, etc.)
            prediction: result.rating_class, // add model prediction
          });
        } else {
          enrichedData.push({
            ...row,
            prediction: "Error",
          });
          console.error("API Error:", result.error);
        }
      } catch (err) {
        enrichedData.push({
          ...row,
          prediction: "Request Failed",
        });
        console.error("Request failed:", err);
      }
    }

    setTableData(enrichedData);
    setShow(true);
    setLoading(false);
  };

  return (
    <div className="min-h-screen p-4">
      <MyDropzone onFileDrop={handleFileDrop} />
      <div className="mt-5">
        {loading && <p className="text-blue-600">Processing file, please wait...</p>}
        {show && <BooksPage data={tableData} />}
      </div>
    </div>
  );
};

export default DropzonesWithTable;
